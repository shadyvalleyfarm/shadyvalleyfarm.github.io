Version: 3.0.0.BUILD-20140422104054
Build Date: 20140422104054

* Adds a Blocking IO (BIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration