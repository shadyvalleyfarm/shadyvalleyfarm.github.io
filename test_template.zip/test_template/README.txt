Version: 3.0.0.CI-606
Build Date: 20140625114510

* Adds a Blocking IO (BIO) connector for HTTP